module.exports = {
  ROLES: {
    ADMIN: "admin",
    USER: "user",
  },
  QUESTION_CATEGORIES: [
    "Politique",
    "Sport",
    "Culture",
    "Santé",
    "People",
    "Religion",
    "Technologie",
    "Actualité"
  ]
};
